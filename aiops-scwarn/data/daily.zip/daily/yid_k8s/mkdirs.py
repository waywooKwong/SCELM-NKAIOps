import os

# 指定文件夹路径
for i in range(19,65):

# 使用os.makedirs()函数创建文件夹
    os.mkdir('100'+str(i))

