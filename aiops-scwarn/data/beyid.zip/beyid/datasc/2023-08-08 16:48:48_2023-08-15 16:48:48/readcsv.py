import csv

def read_csv_rows(input_file, output_file, num_rows):
    with open(input_file, 'r', newline='', encoding='utf-8') as file:
        reader = csv.reader(file)
        rows = [next(reader) for _ in range(num_rows)]  # 读取前 num_rows 行

    with open(output_file, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerows(rows)

# 指定输入文件路径和输出文件路径
input_file_path = 'train_log.csv'
output_file_path = 'test_log.csv'

# 指定要读取的行数
num_rows_to_read = 722

# 调用函数
read_csv_rows(input_file_path, output_file_path, num_rows_to_read)
